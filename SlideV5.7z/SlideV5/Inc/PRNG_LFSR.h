#ifndef PRNG_LFSR_H_
#define PRNG_LFSR_H_

#include <stdio.h>

void init_LFSR(uint32_t valor);
uint32_t  prng_LFSR() ;

#endif /* PRNG_LFSR_H_ */
